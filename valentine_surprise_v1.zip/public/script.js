document.addEventListener('DOMContentLoaded', () => {
    const noBtn = document.getElementById('no-btn');
    const yesBtn = document.getElementById('yes-btn');
    const overlay = document.getElementById('valentine-overlay');
    const mainContent = document.getElementById('main-content');
    const todoList = document.getElementById('todo-list');
    const newTodoInput = document.getElementById('new-todo');
    const addBtn = document.getElementById('add-btn');

    // 1. "No" Button Interaction
    noBtn.addEventListener('mouseover', moveButton);
    noBtn.addEventListener('click', moveButton);
    noBtn.addEventListener('touchstart', (e) => {
        e.preventDefault(); // Prevent click simulation
        moveButton();
    });

    function moveButton() {
        const padding = 20; // Buffer from edge

        // Use the smaller dimension to prevent overflow on mobile browsers with bars
        const vw = Math.min(window.innerWidth, document.documentElement.clientWidth);
        const vh = Math.min(window.innerHeight, document.documentElement.clientHeight);

        // Ensure accurate button dimensions
        // Fallback to minimal dimensions just in case offsetWidth is 0 (hidden)
        const btnW = noBtn.offsetWidth || 100;
        const btnH = noBtn.offsetHeight || 40;

        // Calculate safe boundaries
        const maxLeft = vw - btnW - padding;
        const maxTop = vh - btnH - padding;

        // Generate random position within safe bounds
        // Math.max(padding, ...) ensures we don't return negative values if screen is too small
        const x = Math.max(padding, Math.random() * maxLeft);
        const y = Math.max(padding, Math.random() * maxTop);

        noBtn.style.position = 'fixed';
        noBtn.style.left = `${x}px`;
        noBtn.style.top = `${y}px`;
        noBtn.style.zIndex = '9999'; // Ensure it stays on top of everything
    }

    // 2. "Yes" Button Interaction
    yesBtn.addEventListener('click', () => {
        overlay.classList.add('hidden');
        mainContent.classList.remove('hidden');
        startCountdowns();
        loadTodos(); // Load todos only when entering main site
    });

    // 3. Countdowns
    const dates = {
        'valentine': new Date('2026-02-14T00:00:00'),
        '1-5-years': new Date('2026-02-26T00:00:00'),
        '2-years': new Date('2026-02-28T00:00:00')
    };

    function startCountdowns() {
        setInterval(() => {
            const now = new Date();
            for (const [id, targetDate] of Object.entries(dates)) {
                const diff = targetDate - now;
                const element = document.getElementById(`timer-${id}`);

                if (diff <= 0) {
                    element.innerHTML = "הגיע הזמן! ❤️";
                } else {
                    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
                    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
                    const seconds = Math.floor((diff % (1000 * 60)) / 1000);
                    element.innerHTML = `${days} ימים, ${hours}:${minutes}:${seconds}`;
                }
            }
        }, 1000);
    }

    // 4. Todo List Logic
    let todos = [];

    async function loadTodos() {
        const res = await fetch('/api/todos');
        todos = await res.json();
        renderTodos();
    }

    async function saveTodos() {
        await fetch('/api/todos', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(todos)
        });
        // No need to reload, local state is source of truth until next refresh
    }

    function renderTodos() {
        todoList.innerHTML = '';
        todos.forEach((todo, index) => {
            const li = document.createElement('li');
            li.className = `todo-item ${todo.completed ? 'completed' : ''}`;

            // Checkbox container
            const checkbox = document.createElement('div');
            checkbox.className = 'todo-checkbox';
            checkbox.addEventListener('click', () => toggleTodo(index));

            // Text content
            const span = document.createElement('span');
            span.className = 'todo-text';
            span.textContent = todo.text;
            span.addEventListener('click', () => toggleTodo(index));

            // Delete button
            const btn = document.createElement('button');
            btn.innerHTML = '🗑️';
            btn.className = 'delete-btn';
            btn.title = 'מחיקה';
            btn.addEventListener('click', (e) => {
                e.stopPropagation(); // Prevent toggle
                deleteTodo(index);
            });

            li.appendChild(checkbox);
            li.appendChild(span);
            li.appendChild(btn);
            todoList.appendChild(li);
        });
    }

    function addTodo() {
        const text = newTodoInput.value.trim();
        if (text) {
            todos.push({ text, completed: false });
            newTodoInput.value = '';
            renderTodos();
            saveTodos();
        }
    }

    function toggleTodo(index) {
        todos[index].completed = !todos[index].completed;
        renderTodos();
        saveTodos();
    }

    function deleteTodo(index) {
        todos.splice(index, 1);
        renderTodos();
        saveTodos();
    }

    addBtn.addEventListener('click', addTodo);
    newTodoInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') addTodo();
    });

    // 5. Tabs Logic
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            // Remove active class from all buttons and contents
            tabBtns.forEach(b => b.classList.remove('active'));
            tabContents.forEach(c => {
                c.classList.remove('active');
                c.classList.add('hidden');
            });

            // Add active class to clicked button
            btn.classList.add('active');

            // Show corresponding content
            const tabId = btn.getAttribute('data-tab');
            const content = document.getElementById(`tab-${tabId}`);
            content.classList.add('active');
            content.classList.remove('hidden');
        });
    });
});
