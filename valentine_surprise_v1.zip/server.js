const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;
const DATA_FILE = path.join(__dirname, 'todos.json');

app.use(bodyParser.json());
app.use(express.static('public'));

// Helper to read data
const readData = () => {
    if (!fs.existsSync(DATA_FILE)) {
        return [];
    }
    const data = fs.readFileSync(DATA_FILE);
    return JSON.parse(data);
};

// Helper to write data
const writeData = (data) => {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
};

// Get todos
app.get('/api/todos', (req, res) => {
    res.json(readData());
});

// Save todos (full sync for simplicity)
app.post('/api/todos', (req, res) => {
    const todos = req.body;
    writeData(todos);
    res.status(200).send('Saved');
});

app.listen(PORT, () => {
    console.log(`Server is running heavily on http://localhost:${PORT}`);
});
